DATOS DEL PROYECTO ENSO–BAJA (VERSIÓN DUMMY)

Los datos de esta carpeta son sintéticos y fueron generados únicamente para
las prácticas del minicurso. No representan observaciones reales.

1) sst_baja_mensual_1994_2024.nc
   - Formato: NetCDF
   - Variable principal: sst
   - Dimensiones: time, lat, lon
   - Frecuencia: mensual
   - Dominio aproximado: Pacífico frente a Baja California
   - Unidades: grados Celsius

2) precipitacion_ensenada_mensual.csv
   - Formato: CSV
   - Columnas: fecha, precipitacion_mm
   - Frecuencia: mensual
   - Unidades: mm/mes

3) oni_mensual.csv
   - Formato: CSV
   - Columnas: fecha, oni
   - Frecuencia: mensual
   - Unidades: grados Celsius (índice sintético)

En las siguientes sesiones usaremos estos tres tipos de datos para practicar:
- exploración de NetCDF con xarray;
- lectura de tablas con pandas;
- cálculo de climatologías y anomalías;
- visualización de series de tiempo;
- comparación entre variables;
- control de versiones con Git.
