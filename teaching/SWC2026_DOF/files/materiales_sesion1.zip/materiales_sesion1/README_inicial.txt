MINICURSO: INTRODUCCIÓN A HERRAMIENTAS COMPUTACIONALES PARA OCEANOGRAFÍA FÍSICA
Sesión 1 — La terminal y el proyecto ENSO–Baja

Esta carpeta contiene los materiales iniciales del proyecto.

IMPORTANTE
---------
Los archivos de datos incluidos aquí son DATOS SINTÉTICOS (dummy), creados
exclusivamente para practicar terminal, Python, xarray, pandas y Git.
NO deben utilizarse para interpretación científica.

Contenido inicial
-----------------
descargas/
    sst_baja_mensual_1994_2024.nc
    precipitacion_ensenada_mensual.csv
    oni_mensual.csv

notas/
    README_datos.txt
    preguntas_proyecto.txt

environment.yml
    Ambiente conda sugerido para las sesiones 1–3.

verificar_ambiente.py
    Script pequeño para comprobar que las bibliotecas principales están instaladas.

La idea de la sesión 1 es NO trabajar directamente dentro de esta carpeta.
Durante la clase crearás un nuevo proyecto llamado enso_baja/ y copiarás allí
los archivos que necesites.

Preparación del ambiente (una sola vez)
---------------------------------------
Desde esta carpeta:

    conda env create -f environment.yml

Después, cada vez que trabajes en el curso:

    conda activate oceanografia

Para comprobar la instalación:

    python verificar_ambiente.py

Para abrir JupyterLab:

    jupyter lab
