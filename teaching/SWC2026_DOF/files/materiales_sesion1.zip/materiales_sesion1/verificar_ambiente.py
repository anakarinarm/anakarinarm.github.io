"""Comprobación mínima del ambiente del minicurso."""

import sys

import matplotlib
import numpy
import pandas
import xarray

print("Python:", sys.version.split()[0])
print("NumPy:", numpy.__version__)
print("pandas:", pandas.__version__)
print("xarray:", xarray.__version__)
print("matplotlib:", matplotlib.__version__)
print("\nAmbiente listo para el minicurso.")
