# Datos del minicurso 2026

Este directorio contiene los datos preparados para la sesión de Python del
minicurso de Introducción a herramientas computacionales para Oceanografía Física.

## `sst_baja_1981_2026.nc`

- Formato: NetCDF4
- Periodo: 1981-09 a 2026-08
- Resolución temporal: mensual
- Variables:
  - `sst(time, lat, lon)`: temperatura superficial del mar, °C
  - `ssta(time, lat, lon)`: anomalía de temperatura superficial del mar, °C
- Fuente SST/SSTA: NOAA OISST V2.1
- Dominio:
  - latitud: 21.125 a 35.375 °N
  - longitud: -124.875 a -108.625 °E
- Resolución espacial aproximada: 0.25° × 0.25°

**Nota sobre SSTA:** el archivo original no documenta el periodo climatológico
de referencia empleado para calcular `ssta`; por ello no se añadió uno de manera
inferida.

## `oni_mensual_1981_2026.csv`

Columnas:

- `time`: fecha mensual
- `oni_degC`: Oceanic Niño Index (ONI), °C

ONI representa la anomalía de SST en la región Niño 3.4 suavizada mediante
promedios móviles de tres meses.

## `precipitacion_ensenada_1981_2026.csv`

Columnas:

- `time`: fecha mensual
- `precip_mm`: precipitación mensual acumulada, mm

Sitio: presa en Ensenada.

- Latitud: 31°53'29.5"N = 31.891528°
- Longitud: 116°36'11.7"W = -116.603250°

Los campos vacíos representan datos faltantes (`NaN`).

## Lectura rápida en Python

```python
import xarray as xr
import pandas as pd

sst = xr.open_dataset("sst_baja_1981_2026.nc")
oni = pd.read_csv("oni_mensual_1981_2026.csv", parse_dates=["time"])
precip = pd.read_csv("precipitacion_ensenada_1981_2026.csv", parse_dates=["time"])
```
